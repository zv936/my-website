// ღამის რეჟიმის გადართვა
function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

// ფორმის გაგზავნის შეტყობინება
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("შეტყობინება წარმატებით გაიგზავნა!");
      form.reset();
    });
  }

  const contactBtn = document.querySelector(".btn");
  if (contactBtn) {
    contactBtn.addEventListener("click", function (e) {
      e.preventDefault();
      document.getElementById("contact").scrollIntoView({ behavior: "smooth" });
    });
  }
});
